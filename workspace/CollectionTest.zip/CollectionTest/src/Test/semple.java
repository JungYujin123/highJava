package Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class semple {
	public static void main(String[] args) {
		List<Student> list = new ArrayList<>();
		list.add(new Student("1", "홍길동", 85, 95, 20));
		list.add(new Student("5", "임꺽정", 70, 77, 88));
		list.add(new Student("3", "김자바", 35, 50, 79));
		list.add(new Student("6", "김정호", 93, 91, 84));
		list.add(new Student("4", "단군", 85, 51, 64));
		list.add(new Student("2", "강감찬", 70, 90, 40));
		
		Collections.shuffle(list);
		
		System.out.println("정렬 전>>");
		for (Student student : list) {
			System.out.println(student);
		}
		
		System.out.println();
		System.out.println("학번의 오름차순 정렬후 >>");
		Collections.sort(list);
		for (Student student : list) {
			System.out.println(student);
		}
		System.out.println();
		
		System.out.println("총점 내림차순 정렬 후>>");
		Collections.sort(list, new SortStudentNumDesc());
		for (int i = 0; i < list.size(); i++) {
			Student student = list.get(i);
			student.setRank(i+1);
			System.out.println(student);
		}
		
	}
}

class SortStudentNumDesc implements Comparator<Student> {
	@Override
	public int compare(Student o1, Student o2) {
		if (o1.getScoreTotal() > o2.getScoreTotal()) {
			return -1;
		} else if (o1.getScoreTotal() == o2.getScoreTotal()) {
			if(Integer.parseInt(o1.getStudentNO())> Integer.parseInt(o2.getStudentNO())) {
				return -1;
			} else {
				return 1;
			}
		} else {
			return 1;
		}
	}
}

class Student implements Comparable<Student>{
	private String studentNO;
	private String name;
	private int scoreKR;
	private int scoreEN;
	private int scoreMath;
	private int scoreTotal;
	private int scoreAvg;
	private int rank;
	
	public Student(String studentNO, String name, int scoreKR, int scoreEN, int scoreMath) {
		super();
		this.studentNO = studentNO;
		this.name = name;
		this.scoreKR = scoreKR;
		this.scoreEN = scoreEN;
		this.scoreMath = scoreMath;
		this.scoreTotal = scoreKR + scoreEN + scoreMath;
		this.scoreAvg = this.scoreTotal / 3;
	}

	public String getStudentNO() {
		return studentNO;
	}

	public void setStudentNO(String studentNO) {
		this.studentNO = studentNO;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScoreKR() {
		return scoreKR;
	}

	public void setScoreKR(int scoreKR) {
		this.scoreKR = scoreKR;
	}

	public int getScoreEN() {
		return scoreEN;
	}

	public void setScoreEN(int scoreEN) {
		this.scoreEN = scoreEN;
	}

	public int getScoreMath() {
		return scoreMath;
	}

	public void setScoreMath(int scoreMath) {
		this.scoreMath = scoreMath;
	}

	public int getScoreTotal() {
		return scoreTotal;
	}

	public void setScoreTotal(int scoreTotal) {
		this.scoreTotal = scoreTotal;
	}

	public int getScoreAvg() {
		return scoreAvg;
	}

	public void setScoreAvg(int scoreAvg) {
		this.scoreAvg = scoreAvg;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	@Override
	public String toString() {
		return "Student [studentNO=" + studentNO + ", name=" + name + ", scoreKR=" + scoreKR + ", scoreEN=" + scoreEN
				+ ", scoreMath=" + scoreMath + ", scoreTotal=" + scoreTotal + ", scoreAvg=" + scoreAvg + ", rank="
				+ rank + "]";
	}

	@Override
	public int compareTo(Student stu) {
		return getStudentNO().compareTo(stu.getStudentNO());
	}
}
